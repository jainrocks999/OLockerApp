export default {
    bc:'#5A4392',
    textColor:'#333333',
    white:'#fff',
    heading:'#777777',
    black:'#000',
    card:'#E5E5E5',
    heading1:'#777777'
    };
  