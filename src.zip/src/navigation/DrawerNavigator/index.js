import * as React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import DrawerContent from '../../components/Drawer';
import HomeScreen from '../../screens/Main/HomeScreen';
 const Drawer = createDrawerNavigator();
function MyDrawer() {
   
  return (

    <Drawer.Navigator>
        {/* <Drawer.Screen name="Home" component={HomeScreen} /> */}
    </Drawer.Navigator>
  );

}
export default MyDrawer;




