import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList, ScrollView,Image,Dimensions} from 'react-native';
import Header from '../../../components/CustomHeader';
import { useNavigation } from '@react-navigation/native';
import { useSelector,useDispatch} from 'react-redux';
import ImagePath from '../../../components/ImagePath';
import styles from './styles';
import Loader from '../../../components/Loader'
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';

const MyProducts = () => {
    const navigation=useNavigation()
    const dispatch=useDispatch()
    const isFatching =useSelector(state=>state.isFetching)
    const selector=useSelector(state=>state.categoryDetailData1.RetailerFavProduct)
  console.log('vkm user respons Selector', selector);
  const win = Dimensions.get('window');

  const manageCategory1= async(SrNo)=>{
       
    dispatch({
      type: 'Get_GetProductDetail_Request',
      url:'GetProductDetail',
    
     ProductId:SrNo,
      navigation
    })
  }

  return (
    <View style={styles.container}>
      <Header
        source={require('../../../assets/L.png')}
        source2={require('../../../assets/Fo.png')}
        //  source2={require('../../../assets/Image/dil.png')}
        title={'Favourite List'}
        onPress={() => navigation.goBack()}
        onPress2={() => navigation.navigate('Message')}
      />
      <ScrollView>
        {isFatching?<Loader/>:null}
        <View style={styles.main}>
          
          <View>
            <Text style={styles.text}>{selector?.length} Items</Text>
          </View>
         
        </View>
        <View style={styles.card}>
          <FlatList
            data={selector}
            numColumns={2}
            renderItem={({item}) => (
              <TouchableOpacity
              onPress={()=>manageCategory1(item.Product)}
                // navigation.navigate('SubCategory')}
              
                style={styles.cardview}>
                   <View style={{
             height: hp('100%'),
             width:wp('45%'),
          }}>


<View style={{height: hp('7%'), width: '100%',borderWidth:0}}>

                      
<View style={{padding:0,height: hp('5%'), width: '15%',borderWidth:0,marginTop:10,borderWidth:0}}>
  <Image style={{height:hp('2.4%'),width:wp('6%'),marginLeft:3}} source={require('../../../assets/Image/dil.png')}/>
   <Image style={{height:hp('2.2%'),width:wp('7%'),marginTop:5,marginLeft:7}} source={require('../../../assets/Image/share1.png')}/>
</View>
<View style={{ borderTopRightRadius: 10,
borderBottomLeftRadius: 10,
//  paddingHorizontal: 10,
backgroundColor: '#24a31e',
// paddingVertical: 3,
marginTop:Platform.OS=='android'?-47:-52,
alignSelf: 'flex-end',
height: hp('2%'),
width: '45%'}}>

<Text style={styles.cardview2text}>{`${item.ProductDetails?.Weight} GM`}</Text>

</View>
</View>
<View style={{height: hp('13%'), width: wp('33%'),marginLeft:19, maxHeight: hp('14%'),borderWidth:0}}>
{item.ProductDetails?.ProductImageList.map((item1)=>
                   <Image style={{ width: win.width * 0.35,
                    height: '100%',
                    resizeMode: 'contain',
                    alignSelf: 'center',
                    // borderWidth: 5,
                    }}
                   source={{uri:`${ImagePath.Path}${(item1?.ImageLocation)?.substring(1)}`}}
                  />
                  )}

{/* {console.log('image url in list ',`${ImagePath.Path}${(item.Url).substring(2) }`)} */}
</View>
<View style={{height: hp('3%'), width: '100%',marginLeft:20}}>
<Text style={styles.cardbottomtext}>
{`ID# ${item.ProductDetails?.ProductSku}`}
</Text>
<View style={styles.cardbottom1}>
<Image style={{width:16,height:20}} source={require('../../../assets/Image/rupay.png')}/>
<Text style={styles.cardbottom1text}>
{item.ProductDetails?.FullPayment}
</Text>
</View>
</View>
                </View>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={{height: 70}} />
      </ScrollView>
    </View>
  );
};
export default MyProducts;


